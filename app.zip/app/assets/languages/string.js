import React from 'react';
import LocalizedStrings from 'react-native-localization';
const LocalizeString = new LocalizedStrings({
    "en":{
        create_new_game: "CREATE NEW GAME",
        first:"How are You ?",
        second:"I am fine ",
    },
    "he": {
        first:"צור משחק חדש",
        second:"मैं ठीक हूँ ?",
    },
});
export default strings;